//
//  SearchService.swift
//  SwiftUI - Lists
//
//  Created by Stephen on 7/6/22.
//

import Foundation
import FirebaseAuth
import FirebaseFirestore
import FirebaseStorage

class SearchService {
    
    static func searchUsers(input: String, onSuccess: @escaping (_ user: [AppUser]) -> Void) {
        
        
        
        Firestore.firestore().collection("users").whereField("searchName",
            arrayContains:
            input.lowercased().removeWhiteSpace()).getDocuments {
                                                            
//        let ref = Firestore.firestore()
//        let user = ref.collection("users")
//
//        user.getDocuments(){
                                                             
            
            (querysnapshot, err) in
            
            guard let snap = querysnapshot else {
                print("error")
                return
            }
            var users = [AppUser]()
            for document in snap.documents {
                let dict = document.data()
                
                guard let decoded = try? AppUser.init(fromDictionary: dict)
                else { return }
                
                if decoded.uid != Auth.auth().currentUser!.uid {
                    users.append(decoded)
                }
                
                onSuccess(users)
            }
        }
    }
}

