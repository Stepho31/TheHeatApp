//
//  ViewModel(Video List).swift
//  SwiftUI - Lists
//
//  Created by Stephen on 6/23/22.
//

import Foundation

//func toggleFavoritedMode() {
//        self.isFavorited.toggle()
//    }
