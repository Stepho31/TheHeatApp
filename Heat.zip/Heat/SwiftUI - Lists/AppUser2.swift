//
//  AppUser2.swift
//  SwiftUI - Lists
//
//  Created by Stephen on 7/9/22.
//
//
//import Foundation
//
//struct AppUser1: Encodable, Decodable {
//    var uid: String
//    var email: String
//    var profileImageUrl: String
//    var username: String
//    var searchName: [String]
//    var bio: String
//}
