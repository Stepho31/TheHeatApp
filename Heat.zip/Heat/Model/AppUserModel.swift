//
//  AppUser.swift
//  SwiftUI - Lists
//
//  Created by Stephen on 6/22/22.
//

import Foundation

struct AppUser: Encodable, Decodable {
    var uid, email, profileImageUrl, userName: String
    var searchName: [String]
    
    
    init(data: [String: Any]) {
        self.uid = data["uid"] as? String ?? ""
        self.email = data["email"] as? String ?? ""
        self.profileImageUrl = data["profileImageUrl"] as? String ?? ""
        self.userName = data["userName"] as? String ?? ""
        self.searchName = []

    }
}

