//
//  CommentModel.swift
//  
//
//  Created by Stephen on 6/28/22.
//

import Foundation
