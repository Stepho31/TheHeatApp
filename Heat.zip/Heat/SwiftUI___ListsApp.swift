import SwiftUI

@main
struct SwiftUI_List_StarterApp: App {
    
//    let persistenceController = PersistanceController.shared
    
//    @Environment(\.scenePhase) var scenePhase
//    
    var body: some Scene {
        WindowGroup {
//            VideoListView()
            CustomTabBar()
//            CommentView2()
//            Profile()
//            ArtistOfTheWeekView()
//            LoginView(didCompleteLoginProcess: {
//
//            })
//            .environment(\.managedObjectContext, persistenceController.container.viewContext)
//
//        }
//        .onChange(of: scenePhase) { (newScenePhase) in
//            switch newScenePhase {
//                
//            case .background:
//                print("Scene is in background")
//                persistenceController.save()
//            case .inactive:
//                print("Scene is inactive")
//            case .active:
//                print("Scene is active")
//            @unknown default:
//                print("Scene is in background")
//            }
//        }
    }
}
}
