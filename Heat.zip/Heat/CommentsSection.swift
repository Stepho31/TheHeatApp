//
//  CommentsSection.swift
//  
//
//  Created by Stephen on 6/28/22.
//

import SwiftUI

struct CommentsSection: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CommentsSection_Previews: PreviewProvider {
    static var previews: some View {
        CommentsSection()
    }
}
