//
//  CustomTabBar.swift
//  SwiftUI - Lists
//
//  Created by Stephen on 6/16/22.
//

import SwiftUI
import SDWebImageSwiftUI
import CoreData


class CustomTabBarModel: ObservableObject {
    
    
    @Published var errorMessage = ""
    @Published var appUser: AppUser?
    
    init() {
        DispatchQueue.main.async {
            self.isUserCurrentlyLoggedOut = 
            FirebaseManager.shared.auth.currentUser?.uid == nil
        }
        
        fetchCurrentUser()
    }
    func fetchCurrentUser() {
        guard let uid = FirebaseManager.shared.auth.currentUser?.uid else { self.errorMessage = "Could not find Firebase UID"
            return
        }
        
        
        FirebaseManager.shared.firestore.collection("users").document(uid).getDocument { snapshot, error in
            if let error = error {
                self.errorMessage = "Failed to fetch current user: \(error)"
                print("Failed to fetch current user:", error)
                return
            }
            
            guard let data = snapshot?.data() else {
                self.errorMessage = "No data found:"
                return
                
            }
            
            self.appUser = .init(data: data)

        }
    }
    
    @Published var isUserCurrentlyLoggedOut = false
    
    func handleSignOut() {
        isUserCurrentlyLoggedOut.toggle()
        try? FirebaseManager.shared.auth.signOut()
    }
}
struct CustomTabBar: View {
    
    @State var videos: [Video] = VideoList.topTen
    
    @State var selectedIndex = 0
    @State var shouldShowModel = false
    @State var shouldShowLogOutOptions = false
    
    @ObservedObject private var vm = CustomTabBarModel()
    @ObservedObject var favorites = Favorites()
    
    let tabBarImageNames = ["music.note.house", "person.2.crop.square.stack", "flame", "heart", "person.crop.square"]
    
    var body: some View {
        VStack(spacing: 0) {
//            Text("User: \(vm.chatUser?.uid ?? "")")
            HStack(spacing: 16) {
                
                WebImage(url: URL(string: vm.appUser?.profileImageUrl ?? ""))
                    .resizable()
                    .scaledToFill()
                    .frame(width: 50, height: 50)
                    .clipped()
                    .cornerRadius(50)
                    .overlay(RoundedRectangle(cornerRadius: 44)
                        .stroke(Color(.label), lineWidth: 1)
                    )
                .shadow(radius: 5)
                
                VStack(alignment: .leading, spacing: 4) {
                    let email = vm.appUser?.email.replacingOccurrences(of: "@gmail.com", with: "") ?? ""
                    Text(email)
                    .font(.system(size: 24, weight: .bold))
                    HStack {
                        Circle()
                            .foregroundColor(.green)
                            .frame(width: 14, height: 14)
                        Text("online")
                            .font(.system(size: 12))
                            .foregroundColor(Color(.lightGray))
                    }
                    

                }
                Spacer()
                Button {
                    shouldShowLogOutOptions.toggle()
                } label: {
                    Image(systemName: "gear")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(Color(.label))
                    
                }
            }
            .padding()
            .actionSheet(isPresented: $shouldShowLogOutOptions) {
                .init(title: Text("Settings"), message: Text("What do you want to do?"), buttons: [
                    .destructive(Text("Sign Out"), action: {
                        print("handle sign out")
                        vm.handleSignOut()
                    }),
//                    .default(Text("DEFAULT BUTTON")),
                    .cancel()
                ])
            }
            .fullScreenCover(isPresented: $vm.isUserCurrentlyLoggedOut, onDismiss: nil) {
                LoginView(didCompleteLoginProcess: {
                    self.vm.isUserCurrentlyLoggedOut = false
                    self.vm.fetchCurrentUser()
                })
        }
        
            ZStack {
                
                Spacer().fullScreenCover(isPresented: $shouldShowModel, content: {
                    Button(action: {shouldShowModel.toggle()}, label: {
                        ArtistOfTheWeekView()
                    })
                })
                switch selectedIndex {
                case 0:
                    NavigationView {
                        ZStack {
                            WelcomePageView()

                        }
                        
                    }
                case 1:

                        VideoListView()

                case 3:
                    
                FavoritesView()
                    
                default:
//                    NavigationView {
//                    Text("Profile ")
//                }
                    Profile()
                }
                
            }
//            Spacer()
            
            Divider()
                .padding(.bottom, 12)
            
            HStack {
                ForEach(0..<5) { num in
                    Button(action: {
                        if num == 2 {
                            shouldShowModel.toggle()
                        }
                        selectedIndex = num
                    }, label: {
                        Spacer()
                        
                        if num == 2 {
                            Image(systemName: tabBarImageNames[num])
                                .font(.system(size: 45, weight: .bold))
                                .foregroundColor(.red)
                            Spacer()
                            
                        } else {
                            Image(systemName: tabBarImageNames[num])
                                .font(.system(size: 24, weight: .bold))
                                .foregroundColor(selectedIndex == num ? Color(.red) : .init(white: 0.8))
                            Spacer()
                        }
                    })
                    
                }
                
            }
        }
    }
    
    struct CustomTabBar_Previews: PreviewProvider {
        static var previews: some View {
            CustomTabBar()
                .preferredColorScheme(.dark)
            
            CustomTabBar()
        }
    }
}

