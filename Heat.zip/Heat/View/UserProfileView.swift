//
//  UserProfile.swift
//  SwiftUI - Lists
//
//  Created by Stephen on 7/6/22.
//

import SwiftUI
import SDWebImageSwiftUI

struct UserProfile: View {
    
    @State private var value: String = ""
    @State var users: [AppUser] = []
    @State var isLoading = false
    
    func searchUsers() {
        isLoading = true
        
        SearchService.searchUsers(input: value) {
            (users) in
            self.isLoading = false
            self.users = users
        }
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                SearchBar(value: $value).padding()
                    .onChange(of: value, perform: {
                        new in
                        
                        searchUsers()
                    })
                
                if !isLoading {
                    ForEach(users, id:\.uid) {
                        
                        user in
                        
                        NavigationLink(destination: UsersProfileView(user: user)) {
                        
                        
                        
                        //MARK: Change searched user info
                        HStack {
//                            Text("\(user.email)")
                            WebImage(url: URL(string: user.profileImageUrl)!)
                                .resizable()
                                .scaledToFit()
                                .clipShape(Circle())
                                .frame(width: 60, height: 60, alignment: .trailing)
                                .padding()
                            
                            Text(user.email).font(.subheadline).bold()
                            
                        }
//                        Divider().background(Color.black)
                    }
                    }
                }
                
            }
        }.navigationTitle("User Search")
        }
    }

